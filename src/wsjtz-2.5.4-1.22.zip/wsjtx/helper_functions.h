#ifndef HELPER_FUNCTIONS_H
#define HELPER_FUNCTIONS_H
#include <QString>

double tx_duration(QString mode, double trPeriod, int nsps, bool bFast9);

#endif // HELPER_FUNCTIONS_H
