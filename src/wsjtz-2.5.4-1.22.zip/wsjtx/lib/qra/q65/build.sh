gcc -Wall -march=native -pthread -O3 *.c -lpthread -lm -o q65

