/* This is a dummy file required to make the qmake build compatible
   with the CMake build. */

#define STRINGIZE__(X)
