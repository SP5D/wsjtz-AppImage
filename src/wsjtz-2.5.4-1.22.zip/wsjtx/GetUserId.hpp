#ifndef GETUSERID_HPP_
#define GETUSERID_HPP_

#include <QString>

QString get_user_id ();

#endif
