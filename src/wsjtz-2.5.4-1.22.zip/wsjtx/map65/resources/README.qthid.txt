QTHID INFORMATION

Qthid is simple cross platform controller application for the Funcube Dongle
Pro and Pro+ software defined radio receivers.

Author........: OZ9AEC
License.......: GNU General Public License
Site..........: http://www.oz9aec.net/index.php/funcube-dongle/qthid-fcd-controller
Source........: http://sourceforge.net/projects/qthid/files
Yahoo Group ..: https://uk.groups.yahoo.com/neo/groups/FCDevelopment/info

The qthid folder contains two binaries:

* qthid-4.0.exe
* qthid-4.1.exe

QTHID 4.0 is the current stable providing full support for the Funcube Dongle
API available with firmware 18f or later.

QTHID 4.1 is an updated version that supports the new Funcube Dongle Pro+
devices. This does not work with the original Funcube Dongle Pro!

