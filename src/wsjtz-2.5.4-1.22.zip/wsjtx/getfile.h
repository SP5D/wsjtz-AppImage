// -*- Mode: C++ -*-
#ifndef GETFILE_H
#define GETFILE_H
#include <QDebug>

float gran();

#endif // GETFILE_H
